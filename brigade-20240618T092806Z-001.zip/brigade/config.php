<?php

$conn = mysqli_connect('localhost','root','','brigade') or die('connection failed');

?>